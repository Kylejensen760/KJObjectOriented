public interface IFilter
{
    public int[] filter(int[] ary);
}
