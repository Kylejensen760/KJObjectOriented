public interface IDiffAlg
{
    public int difference(String seq1, String seq2);
}
