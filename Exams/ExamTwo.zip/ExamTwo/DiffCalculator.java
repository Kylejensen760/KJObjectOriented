import java.util.*;
import java.io.IOException;

public class DiffCalculator
{
    private List<IDiffAlg> m_diffAlgs;

    public static void main (String [] args) throws IOException
    {
        Scanner in = new Scanner(System.in);

    }
}
